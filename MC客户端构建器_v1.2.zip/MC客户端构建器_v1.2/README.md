# MC 客户端构建器

一个不依赖启动器的 Minecraft 客户端下载 / 配置 / 打包工具。
选好版本和加载器，它会自动下载原版、依赖库、资源文件，调用官方安装器装好 Forge / OptiFine / Fabric / Quilt，
最后打包成一个 zip。把 zip 解压出的文件夹作为 HMCL 的游戏目录，即可直接启动。

## 功能

- 全量版本列表：正式版、快照、远古 Alpha / Beta（900+ 个）
- 原版安装：version json、client jar、libraries、assets、logging
- 加载器：
  - Forge（调用官方 installer 的 `--installClient`，新旧版本都支持）
  - OptiFine（调用官方 Patcher 生成补丁库）
  - Fabric / Quilt（读取官方 meta 生成版本 JSON）
- 下载源：自动（国内优先 BMCLAPI）/ 仅 BMCLAPI / 仅 Mojang 官方
- 下载线程可选 4 / 8 / 16 / 24 / 32，默认 32
- **安装 Java**：内置 Mojang 运行时下载（8 / 16 / 17 / 21 / 25），装好自动加入 Java 列表
- 失败自动换源，SHA-1 校验，按哈希缓存，可断点复用
- 打包成 zip，含 `使用说明.txt`

## 运行

**方式一：可执行文件（推荐）**

双击 `MC客户端构建器.exe`，无需安装 Python。
支持 Windows 10 / 11 64 位。

**方式二：源码**

```bat
run.bat
```

首次运行会自动创建 `.venv` 并安装依赖（需要本机有 Python 3.10+）。
调试时用 `调试启动.bat`，可以看到控制台报错。

> 单文件 exe 首次启动需要解压到临时目录，约 5-10 秒，属正常现象。
> 个别杀毒软件可能对 PyInstaller 单文件误报，加入信任即可。

## 使用步骤

1. 左侧选 Minecraft 版本（可搜索 / 筛选）
2. 选加载器与版本（原版可跳过）
3. 选 Java（Forge 1.13+ 需要 Java 17+，1.12.2 建议 Java 8）
4. 选输出目录，点「开始构建」
5. 完成后到输出目录取 zip

## 在 HMCL 里使用

方式一（推荐）：把 zip 解压出的文件夹整个作为 HMCL 的游戏目录（设置 → 游戏目录）。

方式二：把文件夹里的 `versions`、`libraries`、`assets` 三个目录一起合并进现有 `.minecraft`。

> 注意：`libraries` 和 `assets` 必须一起带，否则加载器版本会缺文件。

## 数据来源

| 内容 | 地址 |
|---|---|
| 版本清单 | BMCLAPI / `piston-meta.mojang.com` |
| 资源 | `resources.download.minecraft.net`（镜像 `/assets`） |
| 库 | `libraries.minecraft.net`、Forge / Fabric Maven |
| Forge 列表 | `bmclapi2.bangbang93.com/forge/minecraft/<mc>` |
| OptiFine 列表 | `bmclapi2.bangbang93.com/optifine/versionlist` |
| Fabric / Quilt | `meta.fabricmc.net` / `meta.quiltmc.org` |

所有文件下载后都会做 SHA-1 校验；校验失败的会重下。

## 已知限制

- 只支持 Windows（打包目标），其他系统未测试。
- 没有 NeoForge：本机网络到 `maven.neoforged.net` 被阻断，做了会是个坏按钮。
- Forge 1.13+ 与 OptiFine 不能叠加（Forge 用 BootstrapLauncher，OptiFine 需要 launchwrapper），工具会明确报错。
- 旧版本（1.12.2 及更早）的 Forge 安装器建议用 Java 8 运行。
- 构建过程不修改你现有的 `.minecraft`，所有内容都在「构建目录/实例名」下。

## 目录

```
MC_Downloader/
├─ app.py            入口
├─ cli.py            命令行（调试用）
├─ verify.py         结构校验器（检查继承链、库、资源是否齐全）
├─ core/             下载 / 安装 / 打包核心
└─ ui/               PySide6 界面
```
