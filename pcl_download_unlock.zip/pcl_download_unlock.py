#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PCL 下载功能解锁工具  v3
================================================================
针对样本：Plain Craft Launcher 2（被剥夺 MC 下载功能的改版）

原理
----
样本在 `PageDownloadInstall.LoaderInit` 里，把本该传给 `PageLoaderInit`
的 `DlClientListLoader` 换成了一个新建的假 Loader：

    New LoaderTask(Of String, DlClientListResult)(
        "关闭下载",
        Sub() Throw New Exception("为遵守相关法律法规……"),
        Nothing, 2)

结果：下载页拿不到版本列表，一点"下载"就抛异常；即便让假 Loader 静默
返回，`LoadMinecraft_OnFinish` 也会因为真 Loader 从未启动而空引用。

本工具把那 48 字节的构造代码替换成一句 `ldsfld DlClientListLoader`，
让真 Loader 回到槽位，由 `PageLoaderInit` 的 AutoRun 正常拉起。

用法
----
    python pcl_download_unlock.py                # 自动查找并修复
    python pcl_download_unlock.py -d             # 只预演，不写文件
    python pcl_download_unlock.py -f <exe>       # 指定文件
    python pcl_download_unlock.py --restore <exe># 从 .bak 还原

无第三方依赖。
"""

import os
import sys
import struct
import shutil
import hashlib
import argparse

# ---------------------------------------------------------------- 特征

# 原始片段：ldstr "关闭下载" … newobj LoaderTask  （48 字节，位于 LoaderInit）
SIG_OLD = bytes.fromhex(
    "7233470170"          # ldstr "关闭下载"
    "7EFB0900042C07"      # ldsfld $IR3-3 ; brfalse
    "7EFB0900042B16"      # ldsfld $IR3-3 ; br
    "7EF9090004"          # ldsfld $I
    "FE0667140006"        # ldftn _Lambda$__R3-3
    "738D05000A"          # newobj delegate
    "25"                  # dup
    "80FB090004"          # stsfld $IR3-3
    "14"                  # ldnull
    "18"                  # ldc.i4.2
    "738E05000A"          # newobj LoaderTask
)

# 修复片段：ldsfld DlClientListLoader (0x0400040F) + nop 填充
SIG_NEW = bytes.fromhex("7E0F040004") + b"\x00" * 43

# 已修复特征（含前面保留的 ldnull）
SIG_DONE = bytes.fromhex("147E0F040004") + b"\x00" * 42

MARKER_TEXT = "为遵守相关法律法规"      # 用于辅助确认样本身份

SEARCH_ROOTS = [
    os.path.expanduser("~/Desktop"),
    os.path.expanduser("~/Downloads"),
    os.path.expanduser("~/Documents"),
    os.getcwd(),
    "D:\\Desktop",
    "D:\\Downloads",
]

EXE_NAME_HINTS = ("plain craft launcher", "pcl")

# ---------------------------------------------------------------- PE 识别


def is_dotnet_pe(data):
    if len(data) < 0x200 or data[:2] != b"MZ":
        return False
    pe = struct.unpack_from("<I", data, 0x3C)[0]
    if data[pe:pe + 4] != b"PE\0\0":
        return False
    nsec = struct.unpack_from("<H", data, pe + 6)[0]
    optsz = struct.unpack_from("<H", data, pe + 20)[0]
    opt = pe + 24
    magic = struct.unpack_from("<H", data, opt)[0]
    dd = opt + (112 if magic == 0x20B else 96)
    clr = struct.unpack_from("<I", data, dd + 14 * 8)[0]
    return clr != 0


def looks_like_pcl(path):
    try:
        data = open(path, "rb").read()
    except OSError:
        return False
    if not is_dotnet_pe(data):
        return False
    return (b"Plain Craft Launcher" in data
            or b"PCL." in data[:2_000_000]
            or MARKER_TEXT.encode("utf-16-le") in data
            or SIG_OLD in data
            or SIG_DONE in data)


def find_candidates():
    seen, out = set(), []
    for root in SEARCH_ROOTS:
        if not os.path.isdir(root):
            continue
        try:
            for name in os.listdir(root):
                low = name.lower()
                if not low.endswith(".exe"):
                    continue
                if not any(h in low for h in EXE_NAME_HINTS):
                    continue
                p = os.path.join(root, name)
                if p in seen or not os.path.isfile(p):
                    continue
                seen.add(p)
                out.append(p)
        except OSError:
            continue
    return out

# ---------------------------------------------------------------- 修补


def patch_file(path, dry=False):
    data = bytearray(open(path, "rb").read())

    if SIG_OLD in data:
        idx = data.find(SIG_OLD)
        print(f"  [i] 命中 LoaderInit 特征 @0x{idx:X}")
    elif SIG_DONE in data:
        print(f"  [=] 已是解锁状态，无需处理：{path}")
        return True
    else:
        print(f"  [!] 未找到目标特征：{path}")
        print("      可能不是该样本，或已被其它方式修改。")
        return False

    if dry:
        print("  [dry-run] 未写入。")
        return True

    bak = path + ".bak"
    if not os.path.exists(bak):
        shutil.copy2(path, bak)
        print(f"  [i] 已备份 : {bak}")

    data[idx:idx + len(SIG_OLD)] = SIG_NEW
    open(path, "wb").write(data)

    sha = hashlib.sha256(data).hexdigest()
    print(f"  [+] 已写入 : ldsfld DlClientListLoader + nop 填充")
    print(f"  [+] 新 SHA256: {sha}")
    return True


def restore(path):
    bak = path + ".bak"
    if not os.path.exists(bak):
        print(f"[!] 找不到备份：{bak}")
        return False
    shutil.copy2(bak, path)
    print(f"[+] 已还原：{path}")
    return True

# ---------------------------------------------------------------- main


def main():
    ap = argparse.ArgumentParser(description="PCL 下载功能解锁工具 v3")
    ap.add_argument("-f", "--file", help="指定 exe 路径")
    ap.add_argument("-d", "--dry-run", action="store_true", help="只预演")
    ap.add_argument("--restore", metavar="EXE", help="从 .bak 还原")
    args = ap.parse_args()

    print("=" * 60)
    print(" PCL 下载功能解锁工具 v3")
    print("=" * 60)

    if args.restore:
        sys.exit(0 if restore(args.restore) else 1)

    if args.file:
        targets = [args.file]
    else:
        print("[*] 查找 Plain Craft Launcher…")
        targets = find_candidates()
        if not targets:
            print("[!] 没找到候选，请用 -f 指定路径。")
            sys.exit(1)
        for t in targets:
            print(f"    - {t}")

    ok = 0
    for t in targets:
        if not os.path.isfile(t):
            print(f"[!] 文件不存在：{t}")
            continue
        if not looks_like_pcl(t):
            print(f"[!] 不像目标样本，跳过：{t}")
            continue
        print()
        if patch_file(t, dry=args.dry_run):
            ok += 1

    print()
    print(f"[*] 完成：成功处理 {ok}/{len(targets)} 个文件。")
    if not args.dry_run and ok:
        print("[*] 已生成 *.bak 备份，可用 --restore 还原。")


if __name__ == "__main__":
    main()
