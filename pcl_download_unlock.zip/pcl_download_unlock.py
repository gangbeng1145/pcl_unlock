#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PCL 下载功能解锁工具  v4
================================================================
支持 PCL 2.99.0.0 / 2.99.0.1，自动识别版本，
可选同时执行「去中心化」（移除 PCL 官方服务器依赖）。

原理
----
PCL 2.99 起官方在 `PageDownloadInstall.LoaderInit` 里把真实的
`DlClientListLoader` 换成了一个新建的假 Loader：

    New LoaderTask(Of String, DlClientListResult)(
        "关闭下载",
        Sub() Throw New Exception("为遵守相关法律法规……"),
        Nothing, 2)

于是下载页拿不到版本列表，一点"下载"就抛异常。

解锁：把那 48 字节的构造代码换成一句 `ldsfld DlClientListLoader`，
      让真 Loader 回到槽位，由 `PageLoaderInit` 的 AutoRun 正常拉起。

去中心化（可选）：
      1. 三处 PCL 官方接口（notice.cfg / notice.json / ServerConfig.json）
         与一个埋点接口等长替换为 127.0.0.1:1，连接立即被拒，走降级逻辑；
      2. 关于页与设置页的两个「检查更新」按钮改为直接返回。

用法
----
    python pcl_download_unlock.py                  # 自动查找，仅解锁
    python pcl_download_unlock.py --decentralize   # 解锁 + 去中心化
    python pcl_download_unlock.py -f <exe>         # 指定文件
    python pcl_download_unlock.py -d               # 只预演
    python pcl_download_unlock.py --restore <exe>  # 从 .bak 还原
    python pcl_download_unlock.py --list           # 查看支持的版本

无第三方依赖。
"""

import os
import sys
import struct
import shutil
import hashlib
import argparse

# ---------------------------------------------------------------- 版本特征

# 每个版本：解锁特征（48 字节）、两个更新按钮的 IL 偏移
VERSIONS = {
    "2.99.0.0": {
        "sig_old": bytes.fromhex(
            "7233470170"
            "7EFB0900042C07"
            "7EFB0900042B16"
            "7EF9090004"
            "FE0667140006"
            "738D05000A25"
            "80FB090004"
            "1418"
            "738E05000A"
        ),
        "btn_offsets": [0x6221A, 0x68BD0],
    },
    "2.99.0.1": {
        "sig_old": bytes.fromhex(
            "7275480170"
            "7EFC0900042C07"
            "7EFC0900042B16"
            "7EFA090004"
            "FE0669140006"
            "738D05000A25"
            "80FC090004"
            "1418"
            "738E05000A"
        ),
        "btn_offsets": [0x6223A, 0x68C3C],
    },
}

# 解锁后的替换片段：ldsfld DlClientListLoader + 43 个 nop
SIG_NEW = bytes.fromhex("7E0F040004") + b"\x00" * 43

# 去中心化：官方服务器地址（UTF-16 存储，等长替换）
OFFICIAL_URLS = [
    "https://pcl2-server-1253424809.file.myqcloud.com/notice.cfg{CDN}",
    "https://pcl2-server-1253424809.file.myqcloud.com/ServerConfig.json{CDN}",
    "https://pcl2-server-1253424809.file.myqcloud.com/notice.json{CDN}",
    "https://ap-shanghai.cls.tencentcs.com/track?topic_id=pcl-remote-1253424809",
]

# 更新按钮的方法体特征：call UpdateCheckByButton(5B) + ret(1B)
BTN_TAIL = b"\x2A"

SEARCH_ROOTS = [
    os.path.expanduser("~/Desktop"),
    os.path.expanduser("~/Downloads"),
    os.path.expanduser("~/Documents"),
    os.getcwd(),
    "D:\\Desktop",
    "D:\\Downloads",
]

EXE_NAME_HINTS = ("plain craft launcher", "pcl")

# ---------------------------------------------------------------- PE 识别


def is_dotnet_pe(data):
    if len(data) < 0x200 or data[:2] != b"MZ":
        return False
    pe = struct.unpack_from("<I", data, 0x3C)[0]
    if data[pe:pe + 4] != b"PE\0\0":
        return False
    opt = pe + 24
    magic = struct.unpack_from("<H", data, opt)[0]
    dd = opt + (112 if magic == 0x20B else 96)
    clr = struct.unpack_from("<I", data, dd + 14 * 8)[0]
    return clr != 0


def looks_like_pcl(path):
    try:
        data = open(path, "rb").read()
    except OSError:
        return False
    if not is_dotnet_pe(data):
        return False
    return (b"Plain Craft Launcher" in data
            or b"PCL." in data[:2_000_000]
            or b"\x51\x51\x51\x51" in data
            or any(v["sig_old"] in data for v in VERSIONS.values()))


def find_candidates():
    seen, out = set(), []
    for root in SEARCH_ROOTS:
        if not os.path.isdir(root):
            continue
        try:
            for name in os.listdir(root):
                low = name.lower()
                if not low.endswith(".exe"):
                    continue
                if not any(h in low for h in EXE_NAME_HINTS):
                    continue
                p = os.path.join(root, name)
                if p in seen or not os.path.isfile(p):
                    continue
                seen.add(p)
                out.append(p)
        except OSError:
            continue
    return out

# ---------------------------------------------------------------- 核心操作


def detect_version(data):
    """返回 (version, offset)；未命中返回 (None, -1)。"""
    for ver, spec in VERSIONS.items():
        i = data.find(spec["sig_old"])
        if i >= 0:
            return ver, i
    return None, -1


def neutralize(url):
    prefix = "https://"
    rest = url[len(prefix):]
    slash = rest.find("/")
    host, path = (rest, "") if slash < 0 else (rest[:slash], rest[slash:])
    newhost = "127.0.0.1:1"
    return prefix + newhost + "_" * (len(host) - len(newhost)) + path


def apply_decentralize(buf, version, verbose=True):
    """原地去中心化，返回改动计数。"""
    n = 0
    data = bytes(buf)
    for url in OFFICIAL_URLS:
        new = neutralize(url)
        if len(new) != len(url):
            raise ValueError("URL 等长替换失败")
        c = data.count(url.encode("utf-16-le"))
        if c:
            data = data.replace(url.encode("utf-16-le"), new.encode("utf-16-le"))
            n += c
            if verbose:
                print(f"    [url] {c} 处 -> {new[:48]}…")
    buf[:] = data

    # 更新按钮：方法体 = 28 <tok4> 2A
    spec = VERSIONS[version]
    for off in spec["btn_offsets"]:
        chunk = bytes(buf[off:off + 6])
        if chunk[0] == 0x28 and chunk[5] == 0x2A:
            buf[off:off + 6] = b"\x2A" + b"\x00" * 4 + b"\x2A"
            n += 1
            if verbose:
                print(f"    [btn] 0x{off:X} -> ret")
    return n


def patch_file(path, dry=False, decentralize=False):
    data = bytearray(open(path, "rb").read())
    ver, off = detect_version(data)

    print(f"  [i] 文件   : {path}")
    if ver is None:
        print("  [!] 未识别到受支持的 PCL 版本（支持：2.99.0.0 / 2.99.0.1）")
        print("      可能不是目标程序，或已被修改过。")
        return False

    print(f"  [i] 版本   : {ver}")
    print(f"  [i] 解锁点 : 0x{off:X}")

    if dry:
        print("  [dry-run] 未写入。")
        if decentralize:
            print("  [dry-run] 去中心化：将替换 4 个官方地址 + 2 个更新按钮")
        return True

    bak = path + ".bak"
    if not os.path.exists(bak):
        shutil.copy2(path, bak)
        print(f"  [i] 已备份 : {bak}")

    data[off:off + 48] = SIG_NEW
    print("  [+] 解锁   : 假 Loader -> DlClientListLoader")

    if decentralize:
        cnt = apply_decentralize(data, ver)
        print(f"  [+] 去中心化: {cnt} 处改动")

    with open(path, "wb") as f:
        f.write(data)

    print(f"  [+] SHA256 : {hashlib.sha256(data).hexdigest()}")
    return True


def restore(path):
    bak = path + ".bak"
    if not os.path.exists(bak):
        print(f"[!] 找不到备份：{bak}")
        return False
    shutil.copy2(bak, path)
    print(f"[+] 已还原：{path}")
    return True

# ---------------------------------------------------------------- main


def main():
    ap = argparse.ArgumentParser(description="PCL 下载功能解锁工具 v4")
    ap.add_argument("-f", "--file", help="指定 exe 路径")
    ap.add_argument("-d", "--dry-run", action="store_true", help="只预演")
    ap.add_argument("--decentralize", action="store_true", help="同时去中心化")
    ap.add_argument("--restore", metavar="EXE", help="从 .bak 还原")
    ap.add_argument("--list", action="store_true", help="列出支持的版本")
    args = ap.parse_args()

    if args.list:
        print("支持的 PCL 版本：")
        for v in VERSIONS:
            print(f"  - {v}")
        return

    print("=" * 62)
    print(" PCL 下载功能解锁工具 v4")
    print("=" * 62)

    if args.restore:
        sys.exit(0 if restore(args.restore) else 1)

    if args.file:
        targets = [args.file]
    else:
        print("[*] 查找 Plain Craft Launcher…")
        targets = find_candidates()
        if not targets:
            print("[!] 没找到候选，请用 -f 指定路径。")
            sys.exit(1)
        for t in targets:
            print(f"    - {t}")

    ok = 0
    for t in targets:
        if not os.path.isfile(t):
            print(f"[!] 文件不存在：{t}")
            continue
        if not looks_like_pcl(t):
            print(f"[!] 不像目标程序，跳过：{t}")
            continue
        print()
        if patch_file(t, dry=args.dry_run, decentralize=args.decentralize):
            ok += 1

    print()
    print(f"[*] 完成：成功处理 {ok}/{len(targets)} 个文件。")
    if not args.dry_run and ok:
        print("[*] 已生成 *.bak 备份，可用 --restore 还原。")


if __name__ == "__main__":
    main()
